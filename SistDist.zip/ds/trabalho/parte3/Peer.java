package ds.trabalho.parte3;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.Clock;
import java.util.Scanner;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.lang.Math;
import java.lang.String;
import java.util.Comparator;
import java.util.PriorityQueue;

public class Peer {
    String host;

    public Peer(String hostname) {
		host   = hostname;
    }
    
    public static void main(String[] args) throws Exception {
		Peer peer = new Peer(args[0]);
		System.out.printf("new peer @ host=%s\n", args[0]);
		new Thread(new Server(args[0], 11111, args[1], args[2], args[3])).start();
		new Thread(new Client(args[0])).start();
    }
}

class Server implements Runnable {
    static String       host;
    static int          port;
    ServerSocket server;
	static int clock = 0;
	static LinkedList<String> ips = new LinkedList<String>();
	static PriorityQueue<String> buffer = new PriorityQueue<String>();
    
    public Server(String host, int port, String host2, String host3, String host4) throws Exception {
		this.host   = host;
		this.port   = port;
		ips.add(host2); ips.add(host3); ips.add(host4);
        server = new ServerSocket(port, 1, InetAddress.getByName(host));
    }

	public static void incrementClock(){
		clock = clock + 1;
	}
	public static void updateClock(int c){
		clock = Math.max(clock, c) + 1;
	}

    @Override
    public void run() {
	try {
	    
	    while(true) {
		try {
		    Socket client = server.accept();
		    String clientAddress = client.getInetAddress().getHostAddress();
		
		    new Thread(new Connection(clientAddress, client)).start();
		}catch(Exception e) {
		    e.printStackTrace();
		}    
	    }
	} catch (Exception e) {
	     e.printStackTrace();
	}
    }
}

class Connection implements Runnable {
    String clientAddress;
    Socket clientSocket;

    public Connection(String clientAddress, Socket clientSocket) {
		this.clientAddress = clientAddress;
		this.clientSocket  = clientSocket;
    }

    @Override
    public void run() {
	/*
	 * prepare socket I/O channels
	 */
	try {
	    BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));    
	    PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
		
	    String command;
	    command = in.readLine();
	    Scanner sc = new Scanner(command);
	    /*
	     * parse command
	     */
	    
	    
	    /*
	     * execute op
	    */
		if(clientAddress.equals(Server.host)){
			Server.incrementClock();
			for( int i = 0; i < Server.ips.size(); i++){
				Socket nextPeer = new Socket(InetAddress.getByName(Server.ips.get(i)), Server.port);
				PrintWriter output = new PrintWriter(nextPeer.getOutputStream(),true);
				output.println(String.valueOf(String.valueOf(Server.clock) + " " + command));
				output.flush();
				nextPeer.close();
			}
		}
		else if(!sc.next().equals("ack")){
			Scanner scan = new Scanner(command);
			int c = Integer.parseInt(scan.next());
			Server.updateClock(c);
			for( int i = 0; i < Server.ips.size(); i++){
				Socket nextPeer = new Socket(InetAddress.getByName(Server.ips.get(i)), Server.port);
				PrintWriter output = new PrintWriter(nextPeer.getOutputStream(),true);
				output.println(String.valueOf("ack " + Server.clock));
				output.flush();
				nextPeer.close();
			}
			Server.buffer.add(command);
			while(!Server.buffer.isEmpty()){
				//Scanner scan = new Scanner(command);
				String text = Server.buffer.poll();
				Scanner var = new Scanner(text);
				Server.updateClock(c);
				if(!var.next().equals("ack"))
					System.out.println("Timestamp: " + Server.clock + " Mensagem: " + var.nextLine());				
			}
		}else
			Server.buffer.add(command);
	    /*
	     * send result
	     */
	    
	    /*
	     * close connection
	     */
	    clientSocket.close();
	} catch(Exception e) {
	    e.printStackTrace();
	}
    }
}

class Client implements Runnable {
    String  host;
    Scanner scanner;
    
    public Client(String host) throws Exception {
		this.host    = host; 
		this.scanner = new Scanner(System.in);
    }

    @Override 
    public void run() {
	try {

	    while (true) {
		try {
		    /*
		     * read command
		     */
			String command = scanner.nextLine();
		    /* 
		     * make connection
		     */
		    Socket socket  = new Socket(InetAddress.getByName(host), Server.port);
		
		    /*
		     * prepare socket I/O channels
		     */
		    PrintWriter   out = new PrintWriter(socket.getOutputStream(), true);
		        
		    /*
		     * send command
		     */
		    out.println(command);
		    out.flush();	    

		    /*
		     * close connection
		     */
		    socket.close();
		} catch(Exception e) {
		    e.printStackTrace();
		}   
	    }
	} catch(Exception e) {
	    e.printStackTrace();
	}   	    
    }
}

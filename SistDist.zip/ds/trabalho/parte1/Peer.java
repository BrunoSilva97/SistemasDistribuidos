package ds.trabalho.parte1;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

class Token{
	public static int token = 0;

	public static int increment(int n){
		token = n + 1;
		return token;
	}

	public static int getToken(){
		return token;
	}
}

public class Peer {
    String host;

    public Peer(String hostname) {
		host   = hostname;
    }
    
    public static void main(String[] args) throws Exception {
		Peer peer = new Peer(args[0]);
		System.out.printf("new peer @ host=%s\n", args[0]);
		new Thread(new Server(args[0], args[1])).start();
		new Thread(new Client(args[0])).start();
    }
}

class Server implements Runnable {
    String       host;
    int          port = 11111;
	static String 		 nextHost;
	static int 		 nextPort = 11111;
    ServerSocket server;
	static boolean lock = false;
    
    public Server(String host, String nextHost) throws Exception {
		this.host   = host;
		this.nextHost = nextHost;
    	server = new ServerSocket(port, 1, InetAddress.getByName(host));
    }

    @Override
    public void run() {
	try {
	    
	    while(true) {
		try {
		    Socket client = server.accept();
		    String clientAddress = client.getInetAddress().getHostAddress();
		
		    new Thread(new Connection(clientAddress, client)).start();
		}catch(Exception e) {
		    e.printStackTrace();
		}    
	    }
	} catch (Exception e) {
	     e.printStackTrace();
	}
    }
}

class Connection implements Runnable {
    String clientAddress;
    Socket clientSocket;

    public Connection(String clientAddress, Socket clientSocket) {
		this.clientAddress = clientAddress;
		this.clientSocket  = clientSocket;
    }
	
	public void lock(){
		Server.lock = true;
	}

	public void unlock() throws Exception{
		Server.lock = false;
		Socket nextPeer  = new Socket(InetAddress.getByName(Server.nextHost), Server.nextPort);
		PrintWriter   output = new PrintWriter(nextPeer.getOutputStream(), true);
		output.println(String.valueOf(Token.getToken()));
		output.flush();
		nextPeer.close();
		System.out.println(Token.getToken());
	}

	public void start() throws Exception{
		if(!Server.lock){
			Socket nextPeer  = new Socket(InetAddress.getByName(Server.nextHost), Server.nextPort);
			PrintWriter   output = new PrintWriter(nextPeer.getOutputStream(), true);
			output.println(String.valueOf(Token.getToken()));
			output.flush();
			nextPeer.close();
			System.out.println(Token.getToken());
		}
	}

    @Override
    public void run() {
	/*
	 * prepare socket I/O channels
	 */
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));    
		
			String command;
			command = in.readLine();
			
			/*
			* parse command
			*/
			Scanner sc = new Scanner(command);
			String  op = sc.next();	     
			/*
			* execute op
			*/
			switch(op) {
				case "lock": lock(); break;
				case "unlock": unlock(); break;
				case "start": start(); break;
				default:{
					Token.increment(Integer.parseInt(op));
					if(!Server.lock){
						TimeUnit.SECONDS.sleep(2);
						Socket nextPeer  = new Socket(InetAddress.getByName(Server.nextHost), Server.nextPort);
						PrintWriter   output = new PrintWriter(nextPeer.getOutputStream(), true);
						output.println(String.valueOf(Token.getToken()));
						output.flush();
						nextPeer.close();
						System.out.println(Token.getToken());
					}
				} 
			}  
			
			/*
			* send result
			*/

			/*
			* close connection
			*/
			clientSocket.close();
		} catch(Exception e) {
			e.printStackTrace();
		}	
	}
}

class Client implements Runnable {
    String  host;
	int serverPort = 11111;
    Scanner scanner;
    
    public Client(String host) throws Exception {
		this.host    = host;
		this.scanner = new Scanner(System.in);
    }

    @Override 
    public void run() {
	try {
	    	
	    /*
	     * send messages such as:
	     *   - call lock/unlock/start
	     */
	    while (true) {
		try {
		    /*
		     * read command
		     */
		    System.out.print("$ ");
		    String command = scanner.next();
		    /* 
		     * make connection
		     */
		    Socket socket  = new Socket(InetAddress.getByName(host), serverPort);
		
		    /*
		     * prepare socket I/O channels
		     */
		    PrintWriter   out = new PrintWriter(socket.getOutputStream(), true);    
		    /*
		     * send command
		     */
		    out.println(command);
		    out.flush();	    
		    /*
		     * receive result
		     */
		  	
			/*
		     * close connection
		     */
		    socket.close();
		} catch(Exception e) {
		    e.printStackTrace();
		}   
	    }
	} catch(Exception e) {
	    e.printStackTrace();
	}   	    
    }
}
